using System.IO;
using System.Text.Json;

namespace KyeForge.App.Services;

/// <summary>Persists the app's remembered keyboard + config between sessions.</summary>
public class AppSettings
{
    private static readonly string Dir = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "KyeForge");
    private static readonly string FilePath = Path.Combine(Dir, "settings.json");

    public string? LastConfigPath { get; set; }
    public string? LastDevicePath { get; set; }
    public string LastDeviceName { get; set; } = "";
    public string LastConfigName { get; set; } = "";

    /// <summary>UI language code: "en" or "ru". Defaults to system language if unset.</summary>
    public string Language { get; set; } = "ru";

    public bool RememberLastDevice { get; set; } = true;
    public bool RememberLastConfig { get; set; } = true;

    /// <summary>True once the one-time "star the repository" prompt has been shown.</summary>
    public bool StarPromptShown { get; set; }

    /// <summary>Position of the navigation bar: "Left", "Top", "Right", "Bottom". Default is "Left".</summary>
    public string SidebarPosition { get; set; } = "Left";

    // ---- Appearance customization (empty = theme default) ----
    /// <summary>UI theme: "dark" (default) or "light".</summary>
    public string Theme { get; set; } = "dark";
    public string AccentColor { get; set; } = "";
    // Surface colors of the dark theme (empty = theme default).
    public string BgColor { get; set; } = "";
    public string PanelColor { get; set; } = "";
    public string CardColor { get; set; } = "";
    public string TextColor { get; set; } = "";
    // Surface colors of the light theme (empty = theme default).
    public string BgColorLight { get; set; } = "";
    public string PanelColorLight { get; set; } = "";
    public string CardColorLight { get; set; } = "";
    public string TextColorLight { get; set; } = "";

    /// <summary>Custom background path: image (png/jpg/bmp/...) or GIF. Empty = none.</summary>
    public string BackgroundImagePath { get; set; } = "";

    /// <summary>Background dim overlay strength, 0..90 (percent).</summary>
    public double BackgroundDim { get; set; } = 55;

    /// <summary>Background blur radius, 0..60 (px).</summary>
    public double BackgroundBlur { get; set; } = 0;

    // ---- Dashboard block layout: page id -> ordered block ids ----
    public Dictionary<string, List<string>> BlockOrders { get; set; } = new();
    public Dictionary<string, List<string>> BlockDefaults { get; set; } = new();

    // ---- Last saved lighting profile (mirrors keyboard EEPROM) ----
    public int? LightingEffect { get; set; }
    public double? LightingBrightness { get; set; }
    public double? LightingSpeed { get; set; }
    public string LightingColor { get; set; } = "";

    private static readonly JsonSerializerOptions Opts = new()
    {
        WriteIndented = true,
        PropertyNameCaseInsensitive = true
    };

    public static AppSettings Load()
    {
        try
        {
            if (File.Exists(FilePath))
            {
                return JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(FilePath), Opts) ?? new AppSettings();
            }
        }
        catch { }
        return new AppSettings();
    }

    public void Save()
    {
        try
        {
            // Other views keep their own AppSettings snapshots. Once the
            // one-time star prompt has been recorded, a later save from an
            // older snapshot must not make it appear again.
            if (!StarPromptShown)
            {
                var current = Load();
                if (current.StarPromptShown) StarPromptShown = true;
            }
            Directory.CreateDirectory(Dir);
            File.WriteAllText(FilePath, JsonSerializer.Serialize(this, Opts));
        }
        catch { }
    }
}
